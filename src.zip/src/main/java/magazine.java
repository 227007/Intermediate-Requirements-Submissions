/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author BLT
 */
import java.util.Date;
public class magazine implements Display  {
    private String issueNo;
    private Date releaseDate;

    public magazine(String issueNo, Date releaseDate) {
        this.issueNo = issueNo;
        this.releaseDate = releaseDate;
    }

    public String getIssueNo() {
        return issueNo;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    @Override
    public String getInfo() {
        return String.format("Issue No: %s, Release Date: %s", issueNo, releaseDate.toString());
    }

    @Override
    public boolean inLoan() {
        return false;
    }
}