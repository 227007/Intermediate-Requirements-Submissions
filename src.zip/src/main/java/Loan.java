/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author BLT
 */
    import java.util.Date;

public class Loan implements Display {
    private Date dueDate;

    public Loan(Date dueDate) {
        this.dueDate = dueDate;
    }

    public Date getDueDate() {
        return dueDate;
    }

    @Override
    public String getInfo() {
        return String.format("Due Date: %s", dueDate.toString());
    }

    @Override
    public boolean inLoan() {
        return false;
    }
}

