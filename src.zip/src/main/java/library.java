/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author BLT
 */
import java.util.ArrayList;
import java.util.List;

public class library {

    private List<Book> books;

    public library() {
        this.books = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public List<Book> getBooks() {
        return books;
    }

    public void saveBooksToFile(String fileName) {
        List<String> bookData = new ArrayList<>();
        for (Book book : books) {
            bookData.add(book.getTitle() + "," + book.getAuthor() + "," + book.getNumber() + ","
                    + book.getGenre() + "," + book.getVersion() + "," + book.getDate().toString());
        }
}
}



